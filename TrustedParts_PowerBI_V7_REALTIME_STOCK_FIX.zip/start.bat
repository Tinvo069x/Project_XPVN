@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TrustedParts Power BI V7 - Realtime Stock Fix

set "PYEXE="
where python >nul 2>nul && set "PYEXE=python"
if not defined PYEXE (
  where py >nul 2>nul && set "PYEXE=py -3"
)
if not defined PYEXE (
  echo Python was not found in PATH.
  echo Install Python or add it to PATH, then run this file again.
  pause
  exit /b 1
)

echo ==============================================================
echo  TrustedParts Power BI V7 - REALTIME STOCK / AUTO BRIDGE
echo ==============================================================
echo Checking local port 8877 and closing an older TrustedParts server...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$c=Get-NetTCPConnection -LocalPort 8877 -State Listen -ErrorAction SilentlyContinue ^| Select-Object -First 1; if($c){ try{$h=Invoke-RestMethod -Uri 'http://127.0.0.1:8877/api/health' -TimeoutSec 2; if($h.app -eq 'trustedparts-stock'){ Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 700; exit 0 } else { exit 12 }} catch { exit 13 }} else { exit 0 }"
set "PORTCHECK=%ERRORLEVEL%"
if "%PORTCHECK%"=="12" (
  echo ERROR: Port 8877 is used by another application.
  echo Close that application, then run start.bat again.
  pause
  exit /b 12
)
if "%PORTCHECK%"=="13" (
  echo ERROR: Port 8877 is already occupied and could not be identified.
  echo Close the program using port 8877, then run start.bat again.
  pause
  exit /b 13
)

echo Local UI: http://127.0.0.1:8877
echo No manual Edge extension installation is required.
echo CONNECT EDGE automatically restarts ONLY the dedicated app Edge profile
echo and loads the local bridge extension.
echo REPAIR EDGE repeats that clean restart if the first connection fails.
echo.
call %PYEXE% app.py
pause
