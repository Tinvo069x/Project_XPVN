from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HTML_NAME = "TrustedParts_PowerBI_Matcher.html"
HOST = "127.0.0.1"
PORT = 8877
MAX_WORKERS = max(1, min(int(os.environ.get("TRUSTEDPARTS_MAX_WORKERS", "2")), 2))
WORKER_FRESH_SECONDS = 10
ASSIGNMENT_TIMEOUT = 30
CACHE_TTL_SECONDS = max(0, int(os.environ.get("TRUSTEDPARTS_CACHE_TTL", "600")))
CACHE_FILE = ROOT / ".trustedparts_cache_v7.json"
PROFILE_DIR = ROOT / ".trustedparts_edge_autobridge_profile"
EXTENSION_DIR = ROOT / "edge_extension"
EXTENSION_READY_MARKER = ROOT / ".trustedparts_extension_ready_v7"


def clean(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ")).strip()


def mpn_key(value):
    return re.sub(r"[^A-Z0-9]", "", clean(value).upper())


def find_edge():
    env = os.environ.get("TRUSTEDPARTS_EDGE") or os.environ.get("EDGE_PATH")
    candidates = [env] if env else []
    for name in ("msedge", "msedge.exe"):
        p = shutil.which(name)
        if p:
            candidates.append(p)
    if sys.platform.startswith("win"):
        for base in filter(None, [os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"), os.environ.get("LOCALAPPDATA")]):
            candidates.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
    elif sys.platform == "darwin":
        candidates.append("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")
    else:
        for name in ("microsoft-edge", "microsoft-edge-stable"):
            p = shutil.which(name)
            if p:
                candidates.append(p)
    seen = set()
    for p in candidates:
        if not p:
            continue
        p = os.path.abspath(p)
        if p in seen:
            continue
        seen.add(p)
        if os.path.isfile(p):
            return p
    return None


EDGE = find_edge()


def trustedparts_url(mpn: str, worker_id: str = "") -> str:
    base = "https://www.trustedparts.com/en/search/" + urllib.parse.quote(clean(mpn), safe=",")
    if worker_id:
        return base + "?" + urllib.parse.urlencode({"tpbi_worker": worker_id})
    return base


def worker_home(worker_id: str) -> str:
    return "https://www.trustedparts.com/en?" + urllib.parse.urlencode({"tpbi_worker": worker_id})


def edge_base_args():
    PROFILE_DIR.mkdir(exist_ok=True)
    return [
        EDGE,
        f"--user-data-dir={PROFILE_DIR}",
        "--no-first-run",
        "--disable-default-apps",
        "--disable-popup-blocking",
    ]


def _kill_dedicated_edge_windows():
    """Close ONLY Edge processes using this app's dedicated profile.

    This matters because Chromium ignores new --load-extension flags when a
    process for the same profile is already alive. V7 restarts only the
    dedicated TrustedParts profile, never the user's normal Edge profile.
    """
    if not sys.platform.startswith("win"):
        return
    profile = str(PROFILE_DIR.resolve()).replace("'", "''")
    ps = (
        "$p='" + profile + "'; "
        "Get-CimInstance Win32_Process -Filter \"Name='msedge.exe'\" | "
        "Where-Object { $_.CommandLine -and $_.CommandLine.Contains($p) } | "
        "ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch {} }"
    )
    try:
        subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=8,
            check=False,
        )
        time.sleep(0.6)
    except Exception:
        pass


def launch_edge_workers(force_restart=True):
    """Start Edge with an automatically loaded local bridge extension.

    The browser profile stays persistent (cookies/session are retained), but
    the extension itself is guaranteed on each fresh dedicated Edge launch.
    No manual edge://extensions setup is required.
    """
    if not EDGE:
        raise RuntimeError("Microsoft Edge was not found")
    if not EXTENSION_DIR.exists():
        raise RuntimeError(f"Extension folder not found: {EXTENSION_DIR}")
    if force_restart:
        _kill_dedicated_edge_windows()
    ext = str(EXTENSION_DIR.resolve())
    urls = [worker_home(str(i + 1)) for i in range(MAX_WORKERS)]
    args = [
        *edge_base_args(),
        f"--disable-extensions-except={ext}",
        f"--load-extension={ext}",
        "--new-window",
        *urls,
    ]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def open_edge_workers():
    # If a worker is already healthy, keep it. Otherwise restart the dedicated
    # profile so Edge cannot silently ignore extension command-line flags.
    connected = sum(1 for w in STATE.workers_payload() if w.get("connected")) if "STATE" in globals() else 0
    if connected:
        return {"restarted": False, "already_connected": connected}
    launch_edge_workers(force_restart=True)
    return {"restarted": True, "already_connected": 0}


def repair_edge_workers():
    launch_edge_workers(force_restart=True)
    return {"restarted": True}


class QueueState:
    def __init__(self):
        self.lock = threading.RLock()
        self.job = None
        self.workers = {}
        self.cache = self._load_cache()

    def _load_cache(self):
        try:
            if CACHE_FILE.exists():
                obj = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
                return obj if isinstance(obj, dict) else {}
        except Exception:
            pass
        return {}

    def _save_cache(self):
        try:
            tmp = CACHE_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.cache, ensure_ascii=False), encoding="utf-8")
            tmp.replace(CACHE_FILE)
        except Exception:
            pass

    def _cache_get(self, mpn):
        if CACHE_TTL_SECONDS <= 0:
            return None
        item = self.cache.get(mpn_key(mpn))
        if not isinstance(item, dict):
            return None
        if time.time() - float(item.get("ts", 0)) > CACHE_TTL_SECONDS:
            return None
        rows = item.get("rows")
        required = {"Distributor", "RoHS", "Datasheet", "DatasheetURL", "Distributor Part #", "Pkg (MOQ)", "Stock", "Pricing", "BuyURL"}
        if not isinstance(rows, list) or not rows:
            return None
        if not all(isinstance(r, dict) and required.issubset(r.keys()) for r in rows):
            return None
        return rows

    def _cache_put(self, mpn, rows):
        if not rows:
            return
        self.cache[mpn_key(mpn)] = {"ts": time.time(), "mpn": mpn, "rows": rows}
        self._save_cache()

    def _worker_connected(self, wid, now=None):
        now = now or time.time()
        w = self.workers.get(wid)
        return bool(w and now - w.get("seen", 0) <= WORKER_FRESH_SECONDS)

    def workers_payload(self):
        now = time.time()
        out = []
        for wid, w in sorted(self.workers.items()):
            age = now - w.get("seen", 0)
            out.append({
                "worker_id": wid,
                "connected": age <= WORKER_FRESH_SECONDS,
                "age": round(age, 1),
                "url": w.get("url", ""),
                "title": w.get("title", ""),
            })
        return out

    def heartbeat(self, wid, url="", title=""):
        wid = clean(wid) or "1"
        with self.lock:
            self.workers[wid] = {"seen": time.time(), "url": clean(url), "title": clean(title)}
            try:
                EXTENSION_READY_MARKER.write_text(
                    json.dumps({"seen": time.time(), "worker_id": wid, "url": clean(url)}, ensure_ascii=False),
                    encoding="utf-8",
                )
            except Exception:
                pass
            return self.job_payload()

    def start_job(self, mpns, force_refresh=False):
        with self.lock:
            if self.job and self.job.get("active"):
                raise RuntimeError("Another TrustedParts job is already running")
            jid = uuid.uuid4().hex
            results = {}
            cached = 0
            if not force_refresh:
                for i, mpn in enumerate(mpns):
                    rows = self._cache_get(mpn)
                    if rows:
                        results[i] = {"inputMPN": mpn, "rows": rows, "cached": True}
                        cached += 1
            self.job = {
                "id": jid,
                "mpns": list(mpns),
                "active": len(results) < len(mpns),
                "cancelled": False,
                "started": time.time(),
                "updated": time.time(),
                "results": results,
                "assignments": {},
                "status": {},
                "concurrency": 1,
                "success_streak": 0,
                "challenge_until": 0.0,
                "cached": cached,
            }
            return jid

    def _reap_stale_assignments(self):
        if not self.job or not self.job.get("active"):
            return
        now = time.time()
        stale = []
        for wid, a in self.job["assignments"].items():
            if now - a.get("claimed", now) > ASSIGNMENT_TIMEOUT and not self._worker_connected(wid, now):
                stale.append(wid)
        for wid in stale:
            self.job["assignments"].pop(wid, None)
            self.job["status"].pop(wid, None)

    def _challenge_active(self):
        j = self.job
        if not j:
            return False
        now = time.time()
        any_verification = any(s.get("status") == "verification" for s in j.get("status", {}).values())
        return any_verification or now < float(j.get("challenge_until", 0))

    def claim(self, wid):
        wid = clean(wid) or "1"
        with self.lock:
            j = self.job
            if not j or not j.get("active"):
                return {"active": False}
            self._reap_stale_assignments()
            if wid in j["assignments"]:
                idx = j["assignments"][wid]["idx"]
                if idx not in j["results"]:
                    return self._assignment_payload(j, wid, idx, j["mpns"][idx])
                j["assignments"].pop(wid, None)

            # Security challenge: do not keep opening more TrustedParts pages.
            if self._challenge_active():
                return {"active": True, "waiting": True, "paused": True, "reason": "security_check", "job_id": j["id"]}

            active_assignments = sum(1 for a in j["assignments"].values() if a["idx"] not in j["results"])
            if active_assignments >= int(j.get("concurrency", 1)):
                return {"active": True, "waiting": True, "job_id": j["id"]}

            assigned_idxs = {a["idx"] for a in j["assignments"].values()}
            next_idx = next((i for i in range(len(j["mpns"])) if i not in j["results"] and i not in assigned_idxs), None)
            if next_idx is None:
                if len(j["results"]) >= len(j["mpns"]):
                    j["active"] = False
                    return {"active": False, "complete": True}
                return {"active": True, "waiting": True, "job_id": j["id"]}

            j["assignments"][wid] = {"idx": next_idx, "claimed": time.time()}
            return self._assignment_payload(j, wid, next_idx, j["mpns"][next_idx])

    def _assignment_payload(self, j, wid, idx, mpn):
        return {
            "active": True,
            "waiting": False,
            "job_id": j["id"],
            "worker_id": wid,
            "index": idx,
            "total": len(j["mpns"]),
            "mpn": mpn,
            "url": trustedparts_url(mpn, wid),
        }

    def set_status(self, wid, job_id, mpn, status, detail=""):
        wid = clean(wid) or "1"
        with self.lock:
            j = self.job
            if not j or j["id"] != job_id:
                return False
            a = j["assignments"].get(wid)
            if not a:
                return False
            expected = j["mpns"][a["idx"]]
            if mpn_key(expected) != mpn_key(mpn):
                return False
            st = clean(status)[:80]
            j["status"][wid] = {"status": st, "detail": clean(detail)[:240], "updated": time.time()}
            if st == "verification":
                j["concurrency"] = 1
                j["success_streak"] = 0
                j["challenge_until"] = time.time() + 20
            elif st in {"waiting_table", "captured", "navigating"}:
                # Once the challenged tab progresses again, don't artificially hold the queue.
                if not any(x.get("status") == "verification" for k, x in j["status"].items() if k != wid):
                    j["challenge_until"] = min(float(j.get("challenge_until", 0)), time.time() + 1)
            j["updated"] = time.time()
            return True

    def submit(self, wid, job_id, mpn, rows, error=""):
        wid = clean(wid) or "1"
        with self.lock:
            j = self.job
            if not j or j["id"] != job_id:
                return {"accepted": False, "reason": "job_not_active"}
            a = j["assignments"].get(wid)
            if not a:
                return {"accepted": False, "reason": "no_assignment"}
            idx = a["idx"]
            expected = j["mpns"][idx]
            if mpn_key(expected) != mpn_key(mpn):
                return {"accepted": False, "reason": "mpn_mismatch", "expected": expected}

            normalized = []
            if isinstance(rows, list):
                seen = set()
                for raw in rows:
                    if not isinstance(raw, dict):
                        continue
                    distributor = clean(raw.get("Distributor"))
                    rohs = clean(raw.get("RoHS"))
                    datasheet = clean(raw.get("Datasheet"))
                    datasheet_url = clean(raw.get("DatasheetURL"))
                    dist_part = clean(raw.get("Distributor Part #"))
                    pkg_moq = clean(raw.get("Pkg (MOQ)"))
                    stock = raw.get("Stock", "")
                    if isinstance(stock, str):
                        st = clean(stock)
                        if re.search(r"out\s+of\s+stock", st, re.I) or (re.search(r"factory\s+lead\s+time", st, re.I) and not re.search(r"\bin\s+stock\b", st, re.I)):
                            stock = 0
                        else:
                            m = re.search(r"\d{1,3}(?:,\d{3})+|\d+", st)
                            stock = int(m.group(0).replace(",", "")) if m else st
                    pricing = clean(raw.get("Pricing"))
                    buy_url = clean(raw.get("BuyURL"))
                    if not (distributor or dist_part or stock != "" or pricing or datasheet_url or buy_url):
                        continue
                    sig = (distributor.casefold(), rohs.casefold(), datasheet.casefold(), datasheet_url.casefold(), dist_part.casefold(), pkg_moq.casefold(), str(stock), pricing.casefold(), buy_url.casefold())
                    if sig in seen:
                        continue
                    seen.add(sig)
                    normalized.append({
                        "Distributor": distributor,
                        "RoHS": rohs,
                        "Datasheet": datasheet,
                        "DatasheetURL": datasheet_url,
                        "Distributor Part #": dist_part,
                        "Pkg (MOQ)": pkg_moq,
                        "Stock": stock,
                        "Pricing": pricing,
                        "BuyURL": buy_url,
                    })

            err = clean(error)
            j["results"][idx] = {"inputMPN": expected, "rows": normalized, **({"error": err} if err else {})}
            j["assignments"].pop(wid, None)
            j["status"].pop(wid, None)
            j["updated"] = time.time()

            if normalized and not err:
                self._cache_put(expected, normalized)
                j["success_streak"] = int(j.get("success_streak", 0)) + 1
                if MAX_WORKERS >= 2 and j["success_streak"] >= 3 and not self._challenge_active():
                    j["concurrency"] = 2
            else:
                j["success_streak"] = 0

            if len(j["results"]) >= len(j["mpns"]):
                j["active"] = False
            return {"accepted": True, "complete": not j["active"], "completed": len(j["results"]), "total": len(j["mpns"]), "concurrency": j["concurrency"]}

    def cancel(self):
        with self.lock:
            if not self.job or not self.job.get("active"):
                return False
            self.job["active"] = False
            self.job["cancelled"] = True
            self.job["updated"] = time.time()
            return True

    def job_payload(self):
        with self.lock:
            now = time.time()
            workers = self.workers_payload() if self.workers else []
            j = self.job
            if not j:
                return {"active": False, "workers": workers}
            status = []
            for wid, a in sorted(j["assignments"].items()):
                idx = a["idx"]
                st = j["status"].get(wid, {})
                status.append({
                    "worker_id": wid,
                    "mpn": j["mpns"][idx],
                    "status": st.get("status", "assigned"),
                    "detail": st.get("detail", ""),
                })
            return {
                "active": bool(j.get("active")),
                "cancelled": bool(j.get("cancelled")),
                "job_id": j["id"],
                "completed": len(j["results"]),
                "total": len(j["mpns"]),
                "elapsed": round(now - j["started"], 1),
                "assignments": status,
                "workers": workers,
                "concurrency": int(j.get("concurrency", 1)),
                "cached": int(j.get("cached", 0)),
                "security_pause": self._challenge_active(),
            }

    def results_payload(self):
        with self.lock:
            j = self.job
            if not j:
                return {"results": []}
            out = []
            for idx, mpn in enumerate(j["mpns"]):
                if idx in j["results"]:
                    out.append(j["results"][idx])
                else:
                    err = "Cancelled" if j.get("cancelled") else "No result returned"
                    out.append({"inputMPN": mpn, "rows": [], "error": err})
            return {"results": out, "active": bool(j.get("active")), "completed": len(j["results"]), "total": len(j["mpns"])}


STATE = QueueState()


class Handler(BaseHTTPRequestHandler):
    server_version = "TrustedPartsPowerBI/6.0-AutoBridge"

    def log_message(self, fmt, *args):
        msg = fmt % args
        if any(x in msg for x in ("GET /api/health ", "GET /api/job ")):
            return
        print("[%s] %s" % (self.log_date_time_string(), msg))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def send_json(self, data, status=200):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > 5_000_000:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(length) or b"{}")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/health":
            workers = STATE.workers_payload()
            connected = sum(1 for w in workers if w["connected"])
            self.send_json({
                "app": "trustedparts-stock",
                "version": "6.0-auto-bridge",
                "port": PORT,
                "browser": bool(EDGE),
                "browser_name": "Microsoft Edge",
                "source": "trustedparts.com/en/search",
                "worker_target": MAX_WORKERS,
                "worker_connected": connected,
                "workers": workers,
                "connection_mode": "persistent_profile_auto_extension",
                "extension_ever_connected": EXTENSION_READY_MARKER.exists(),
                "profile_ready": PROFILE_DIR.exists(),
                "extension_folder": str(EXTENSION_DIR),
            })
            return
        if path == "/api/job":
            self.send_json(STATE.job_payload())
            return
        if path == "/api/results":
            self.send_json(STATE.results_payload())
            return
        if path in ("/", "/index.html", f"/{HTML_NAME}"):
            file = ROOT / HTML_NAME
            if not file.exists():
                self.send_error(404, f"{HTML_NAME} not found")
                return
            raw = file.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)
            return
        self.send_error(404)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        try:
            payload = self.read_json()
            if path == "/api/open-edge":
                info = open_edge_workers()
                self.send_json({
                    "ok": True,
                    "workers": MAX_WORKERS,
                    "mode": "persistent_profile_auto_extension",
                    "auto_load_extension": True,
                    **info,
                })
                return
            if path == "/api/repair-edge":
                info = repair_edge_workers()
                self.send_json({
                    "ok": True,
                    "workers": MAX_WORKERS,
                    "mode": "persistent_profile_auto_extension",
                    "auto_load_extension": True,
                    **info,
                })
                return
            if path == "/api/worker/heartbeat":
                state = STATE.heartbeat(payload.get("worker_id"), payload.get("url"), payload.get("title"))
                self.send_json({"ok": True, "job": state})
                return
            if path == "/api/claim":
                STATE.heartbeat(payload.get("worker_id"), payload.get("url"), payload.get("title"))
                self.send_json(STATE.claim(payload.get("worker_id")))
                return
            if path == "/api/status":
                ok = STATE.set_status(payload.get("worker_id"), clean(payload.get("job_id")), clean(payload.get("mpn")), clean(payload.get("status")), clean(payload.get("detail")))
                self.send_json({"ok": ok})
                return
            if path == "/api/submit":
                result = STATE.submit(payload.get("worker_id"), clean(payload.get("job_id")), clean(payload.get("mpn")), payload.get("rows") or [], clean(payload.get("error")))
                self.send_json(result, 200 if result.get("accepted") else 409)
                return
            if path == "/api/start":
                mpns = payload.get("mpns") or []
                if not isinstance(mpns, list) or not mpns:
                    raise ValueError("mpns must be a non-empty array")
                cleaned, seen = [], set()
                for value in mpns:
                    m = clean(value)
                    k = mpn_key(m)
                    if m and k and k not in seen:
                        seen.add(k); cleaned.append(m)
                if not cleaned:
                    raise ValueError("No valid MPN values")
                if len(cleaned) > 5000:
                    raise ValueError("Maximum 5,000 MPN per run")
                connected = sum(1 for w in STATE.workers_payload() if w["connected"])
                if connected < 1:
                    raise RuntimeError("No Edge worker is connected. Click CONNECT EDGE first.")
                jid = STATE.start_job(cleaned, bool(payload.get("fresh")))
                jp = STATE.job_payload()
                self.send_json({"ok": True, "job_id": jid, "total": len(cleaned), "workers_connected": connected, "cached": jp.get("cached", 0), "concurrency": jp.get("concurrency", 1)})
                return
            if path == "/api/cancel":
                self.send_json({"ok": STATE.cancel()})
                return
            self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc)}, 400)


def main():
    if not (ROOT / HTML_NAME).exists():
        print(f"Missing {HTML_NAME} in {ROOT}")
        raise SystemExit(1)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}/"
    print("==============================================================")
    print(" TrustedParts Power BI V7 - REALTIME STOCK FIX")
    print("==============================================================")
    print(f"Local UI : {url}")
    print(f"Workers  : up to {MAX_WORKERS} Edge tabs; persistent dedicated profile + auto-loaded bridge")
    print("Source   : trustedparts.com/en/search -> visible authorized inventory rows")
    print("Output   : MPN XP | Distributor | RoHS | Datasheet | Distributor Part # | Pkg (MOQ) | Stock | Pricing")
    print("Connect  : no manual extension setup; CONNECT restarts only the dedicated Edge profile and auto-loads the bridge.")
    print("Security : verification pauses new assignments; complete it manually.")
    print(f"Cache    : {CACHE_TTL_SECONDS}s local cache; Force Live Refresh bypasses it")
    print("==============================================================")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
