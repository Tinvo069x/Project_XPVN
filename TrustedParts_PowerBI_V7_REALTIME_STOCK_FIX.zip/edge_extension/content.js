"use strict";

const clean = v => String(v == null ? '' : v).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const norm = v => clean(v).toLowerCase().replace(/[^a-z0-9]/g, '');
const key = v => clean(v).toUpperCase().replace(/[^A-Z0-9]/g, '');

function bridge(path, method = 'GET', body = undefined) {
  return new Promise(resolve => chrome.runtime.sendMessage({type:'bridgeFetch', path, method, body}, r => {
    if (chrome.runtime.lastError) return resolve({ok:false, error:chrome.runtime.lastError.message});
    resolve(r || {ok:false, error:'No bridge response'});
  }));
}

function visible(el) {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  if (r.width <= 0 || r.height <= 0) return false;
  const s = getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
}

function bodyText() { return clean(document.body?.innerText || ''); }
function challengeOpen() {
  const t = bodyText().toLowerCase();
  return [
    'verify you are human','captcha','checking your browser','security verification',
    'access denied','unusual traffic','one more step','please complete the security check',
    'press & hold','press and hold'
  ].some(x => t.includes(x));
}
function noResultPage() {
  const t = bodyText().toLowerCase();
  return t.includes('no results') || t.includes('no matching') || t.includes('0 results') || t.includes('nothing found');
}
function currentPageMPN() {
  try {
    const u = new URL(location.href);
    const m = u.pathname.match(/\/search\/([^/?#]+)/i);
    return m ? clean(decodeURIComponent(m[1])) : '';
  } catch (_) { return ''; }
}
function getWorkerId() {
  try {
    const u = new URL(location.href);
    const q = clean(u.searchParams.get('tpbi_worker'));
    if (q) { sessionStorage.setItem('tpbi_worker', q); return q; }
  } catch (_) {}
  let w = clean(sessionStorage.getItem('tpbi_worker'));
  if (!w) { w = String(Math.floor(Math.random()*900000)+100000); sessionStorage.setItem('tpbi_worker', w); }
  return w;
}

const workerId = getWorkerId();
let assignment = null;
let lastHeartbeat = 0;
let ticking = false;
let timer = null;
let rowsSig = '';
let rowsSince = 0;
let pageStarted = Date.now();
let lastStatus = '';
const MIN_PAGE_AGE_MS = 2200;
const ROWS_STABLE_MS = 1800;

function ensureBanner(text, mode='idle') {
  let el = document.getElementById('__tpbi_v7');
  if (!el) {
    el = document.createElement('div');
    el.id = '__tpbi_v7';
    Object.assign(el.style, {
      position:'fixed', right:'14px', bottom:'14px', zIndex:'2147483647',
      fontFamily:'Segoe UI,Arial,sans-serif', fontSize:'12px', padding:'8px 10px',
      borderRadius:'7px', boxShadow:'0 2px 10px rgba(0,0,0,.18)', maxWidth:'480px'
    });
    document.documentElement.appendChild(el);
  }
  const p = mode === 'ok' ? ['#ecfdf3','#067647','#abefc6'] : mode === 'warn' ? ['#fffaeb','#7a2e0e','#fedf89'] : ['#eff8ff','#175cd3','#b2ddff'];
  el.style.background=p[0]; el.style.color=p[1]; el.style.border='1px solid '+p[2];
  el.textContent=`TrustedParts Power BI W${workerId}: ${text}`;
}

async function heartbeat() {
  const now = Date.now();
  if (now - lastHeartbeat < 5000) return;
  lastHeartbeat = now;
  await bridge('/api/worker/heartbeat','POST',{worker_id:workerId,url:location.href,title:document.title});
}
async function status(st, detail='') {
  if (!assignment) return;
  const sig = st+'|'+detail;
  if (sig === lastStatus) return;
  lastStatus = sig;
  await bridge('/api/status','POST',{worker_id:workerId,job_id:assignment.job_id,mpn:assignment.mpn,status:st,detail});
}

function directCells(row) {
  return [...row.children].filter(el => {
    const t=String(el.tagName||'').toLowerCase(), r=String(el.getAttribute?.('role')||'').toLowerCase();
    return t==='td'||t==='th'||r==='cell'||r==='gridcell'||r==='columnheader';
  });
}
function tableRows(table) {
  const tag=String(table.tagName||'').toLowerCase();
  if (tag==='table') return [...table.rows].filter(r => r.closest('table')===table);
  return [...table.querySelectorAll('[role="row"]')].filter(r => r.closest('[role="table"],[role="grid"]')===table);
}
function isControlText(v) {
  return /^(?:show|see|view)\s*(?:more|less)(?:\s*[+\-…]*)?$/i.test(clean(v));
}
function allTables(root=document) {
  const out=[...root.querySelectorAll('table,[role="table"],[role="grid"]')];
  if (root.matches?.('table,[role="table"],[role="grid"]')) out.unshift(root);
  return out.filter(visible);
}
function cellText(cell) { return clean(cell?.innerText || cell?.textContent || ''); }
function headerIndex(names, aliases) {
  for (let i=0;i<names.length;i++) if (aliases.includes(names[i])) return i;
  for (let i=0;i<names.length;i++) if (aliases.some(a => names[i].includes(a) || a.includes(names[i]))) return i;
  return -1;
}
function absHref(a) {
  if (!a) return '';
  const href=clean(a.getAttribute('href')||'');
  if (!href || href.startsWith('javascript:') || href==='#') return '';
  try { return new URL(href, location.href).href; } catch (_) { return href; }
}
function firstUsefulAnchor(scope) {
  if (!scope) return null;
  return [...scope.querySelectorAll('a[href]')].find(a => absHref(a));
}
function buyAnchor(scope) {
  if (!scope) return null;
  const links=[...scope.querySelectorAll('a[href]')].filter(visible);
  return links.find(a => /^(buy|view|buy now|view now)$/i.test(clean(a.innerText||a.textContent))) ||
         links.find(a => /buy|view/i.test(clean(a.getAttribute('aria-label')||a.getAttribute('title')||''))) || null;
}
function textOrImageLabel(cell) {
  if (!cell) return '';
  let t=cellText(cell);
  const img=cell.querySelector('img');
  const imgLabel=clean(img?.getAttribute('alt')||img?.getAttribute('title')||'');
  if (t && !isControlText(t)) return t;
  if (imgLabel && !isControlText(imgLabel)) return imgLabel;
  const links=[...cell.querySelectorAll('a')];
  for (const a of links) {
    const label=clean(a?.getAttribute('aria-label')||a?.getAttribute('title')||'');
    if (label && !isControlText(label)) return label;
  }
  return isControlText(t) ? '' : t;
}
function stockStatusCandidate(cell) {
  if (!cell) return '';
  const statusRe = /\b(?:in\s+stock|on\s+order|out\s+of\s+stock|available|back\s*order(?:ed)?|backorder(?:ed)?|in\s+transit|factory\s+lead\s+time)\b/i;
  const numRe = /\d{1,3}(?:,\d{3})+|\d+/;
  const cands=[];
  const nodes=[cell,...cell.querySelectorAll('*')];
  for (const el of nodes) {
    if (!visible(el)) continue;
    const t=clean(el.innerText || el.textContent || '');
    if (!t || !statusRe.test(t)) continue;
    // Prefer the smallest visible DOM fragment that contains both quantity + stock status.
    const hasQty=numRe.test(t);
    const score=(hasQty?0:10000)+t.length;
    cands.push({t,score});
  }
  cands.sort((a,b)=>a.score-b.score);
  return cands.length ? cands[0].t : cellText(cell);
}
function parseStock(text) {
  const t=clean(text);
  if (!t) return '';
  if (/out\s+of\s+stock/i.test(t)) return '0';

  // Explicit TrustedParts stock states first. This prevents numbers from pricing,
  // lead-time badges, hidden/stale nodes, etc. from being mistaken for Stock.
  const explicit=[
    /(\d{1,3}(?:,\d{3})+|\d+)\s*in\s+stock\b/i,
    /(\d{1,3}(?:,\d{3})+|\d+)\s*on\s+order\b/i,
    /(\d{1,3}(?:,\d{3})+|\d+)\s*available\b/i,
    /(\d{1,3}(?:,\d{3})+|\d+)\s*(?:back\s*order(?:ed)?|backorder(?:ed)?)\b/i,
    /(\d{1,3}(?:,\d{3})+|\d+)\s*in\s+transit\b/i
  ];
  for (const re of explicit) {
    const m=t.match(re);
    if (m) return m[1];
  }

  if (/factory\s+lead\s+time/i.test(t) && !/\bin\s+stock\b/i.test(t) && !/\bon\s+order\b/i.test(t)) return '0';
  const m=t.match(/\d{1,3}(?:,\d{3})+|\d+/);
  return m ? m[0] : '';
}
function parseStockCell(cell) {
  const preferred=stockStatusCandidate(cell);
  const parsed=parseStock(preferred);
  if (parsed !== '') return parsed;
  return parseStock(cellText(cell));
}
function pricingText(cell) {
  if (!cell) return '';
  let raw=String(cell.innerText || cell.textContent || '').replace(/\u00a0/g,' ');
  raw=raw.replace(/\bSee\s+More(?:\.\.\.)?/gi,' ').trim();
  const compact=clean(raw);
  const pairs=[];
  const re=/(?:^|\s)([\d,.]+)\s+((?:[$€£]\s*\d+(?:\.\d+)?)|(?:\d+(?:\.\d+)?\s*(?:USD|EUR|GBP)))/gi;
  let m;
  while ((m=re.exec(compact))!==null) pairs.push(`${m[1]} ${clean(m[2])}`);
  if (pairs.length) return pairs.join(' | ');
  const lines=raw.split(/\r?\n/).map(clean).filter(Boolean)
    .filter(x=>!/^(?:usd|eur|gbp)(?:\s*\([^)]*\))?$/i.test(x));
  return lines.join(' | ').replace(/\s*\|\s*\|\s*/g,' | ').trim();
}
function datasheetValue(cell) {
  if (!cell) return {text:'',url:''};
  const a=firstUsefulAnchor(cell);
  const url=absHref(a);
  let text=cellText(cell);
  if (!text) {
    const img=cell.querySelector('img');
    text=clean(img?.getAttribute('alt')||img?.getAttribute('title')||a?.getAttribute('aria-label')||a?.getAttribute('title')||'');
  }
  if (url && (!text || /^[-–—]$/.test(text))) text='Datasheet';
  return {text,url};
}

const ALIASES={
  distributor:['authorizeddistributor','distributor','authorizeddist'],
  rohs:['rohs','rohstatus'],
  datasheet:['datasheet','datasheets'],
  distPart:['distributorpart','distributorpartnumber','distributorpartno','sku'],
  pkg:['pkgmoq','pkg','package','packagemoq','packagingmoq'],
  stock:['stock','availability','qty','quantity','inventory'],
  pricing:['pricing','price','unitprice']
};

function inventoryHeaderInfo(table) {
  const rows=tableRows(table);
  for (let i=0;i<Math.min(rows.length,8);i++) {
    const cells=directCells(rows[i]);
    const names=cells.map(c=>norm(cellText(c)));
    const idx={
      distributor:headerIndex(names,ALIASES.distributor),
      rohs:headerIndex(names,ALIASES.rohs),
      datasheet:headerIndex(names,ALIASES.datasheet),
      distPart:headerIndex(names,ALIASES.distPart),
      pkg:headerIndex(names,ALIASES.pkg),
      stock:headerIndex(names,ALIASES.stock),
      pricing:headerIndex(names,ALIASES.pricing)
    };
    if (idx.distributor>=0 && idx.distPart>=0 && idx.stock>=0 && idx.pricing>=0) return {header:i,idx};
  }
  return null;
}
function hasInventoryTable(root) { return allTables(root).some(t => inventoryHeaderInfo(t)); }
function exactMPNElements(expected) {
  const k=key(expected);
  if (!k) return [];
  return [...document.querySelectorAll('a,h1,h2,h3,h4,h5,h6,span,div,strong,b')].filter(el => {
    if (!visible(el)) return false;
    const t=clean(el.innerText||el.textContent);
    return t && key(t)===k;
  });
}
function findProductRoots(expected) {
  const cands=[];
  for (const el of exactMPNElements(expected)) {
    let p=el;
    for (let depth=0; depth<16 && p; depth++,p=p.parentElement) {
      if (!visible(p)) continue;
      if (hasInventoryTable(p)) {
        const r=p.getBoundingClientRect();
        cands.push({p,area:Math.max(1,r.width*r.height),depth});
        break;
      }
    }
  }
  cands.sort((a,b)=>a.area-b.area || a.depth-b.depth);
  const out=[];
  for (const x of cands) if (!out.some(y=>y===x.p || y.contains(x.p) || x.p.contains(y))) out.push(x.p);
  return out;
}
function candidateTables(expected) {
  const roots=findProductRoots(expected);
  const out=[];
  for (const root of roots) for (const t of allTables(root)) if (inventoryHeaderInfo(t) && !out.includes(t)) out.push(t);
  if (out.length) return out;
  const all=allTables(document).filter(t=>inventoryHeaderInfo(t));
  if (all.length===1) return all;
  const exact=exactMPNElements(expected);
  for (const t of all) {
    let p=t.parentElement;
    for (let depth=0; depth<8 && p; depth++,p=p.parentElement) {
      if (exact.some(el=>p.contains(el))) { out.push(t); break; }
    }
  }
  return [...new Set(out)];
}
function rowBuyURL(row) {
  const a=buyAnchor(row);
  return absHref(a);
}
function extractRows(expected) {
  const out=[];
  for (const table of candidateTables(expected)) {
    const info=inventoryHeaderInfo(table);
    if (!info) continue;
    const trs=tableRows(table);
    for (let i=info.header+1;i<trs.length;i++) {
      const row=trs[i]; if (!visible(row)) continue;
      const cells=directCells(row); if (!cells.length) continue;
      const getCell=idx => idx>=0 && idx<cells.length ? cells[idx] : null;
      const get=idx => cellText(getCell(idx));
      const distributorCell=getCell(info.idx.distributor);
      const distributor=textOrImageLabel(distributorCell);
      const rohs=textOrImageLabel(getCell(info.idx.rohs));
      const ds=datasheetValue(getCell(info.idx.datasheet));
      const distPart=get(info.idx.distPart);
      const pkg=get(info.idx.pkg);
      const stockCell=getCell(info.idx.stock);
      const stockText=stockStatusCandidate(stockCell) || get(info.idx.stock);
      let stock=parseStockCell(stockCell);
      const pricing=pricingText(getCell(info.idx.pricing));
      const buyURL=rowBuyURL(row);
      const rawDistributor=cellText(distributorCell);
      const rowText=clean(row.innerText||row.textContent||'');
      if (isControlText(rowText) || (isControlText(rawDistributor) && !distributor)) continue;
      if (!distributor) continue;
      if (!(distPart || stockText || pricing || buyURL || ds.url || pkg || rohs)) continue;
      out.push({
        'Distributor':distributor,
        'RoHS':rohs,
        'Datasheet':ds.text,
        'DatasheetURL':ds.url,
        'Distributor Part #':distPart,
        'Pkg (MOQ)':pkg,
        'Stock':stock,
        'Pricing':pricing,
        'BuyURL':buyURL
      });
    }
  }
  return dedupeRows(out);
}
function dedupeRows(rows) {
  const out=[], seen=new Set();
  for (const raw of rows) {
    const r={
      'Distributor':clean(raw?.Distributor),
      'RoHS':clean(raw?.RoHS),
      'Datasheet':clean(raw?.Datasheet),
      'DatasheetURL':clean(raw?.DatasheetURL),
      'Distributor Part #':clean(raw?.['Distributor Part #']),
      'Pkg (MOQ)':clean(raw?.['Pkg (MOQ)']),
      'Stock':clean(raw?.Stock),
      'Pricing':clean(raw?.Pricing),
      'BuyURL':clean(raw?.BuyURL)
    };
    if (!r.Distributor || isControlText(r.Distributor)) continue;
    if (!(r['Distributor Part #'] || r.Stock!=='' || r.Pricing || r.DatasheetURL || r.BuyURL || r['Pkg (MOQ)'] || r.RoHS)) continue;
    const sig=[r.Distributor,r.RoHS,r.Datasheet,r.DatasheetURL,r['Distributor Part #'],r['Pkg (MOQ)'],r.Stock,r.Pricing,r.BuyURL].map(x=>String(x).toLowerCase()).join('|');
    if (seen.has(sig)) continue;
    seen.add(sig); out.push(r);
  }
  return out;
}

async function claim() {
  const r=await bridge('/api/claim','POST',{worker_id:workerId,url:location.href,title:document.title});
  if(!r.ok||!r.data) return null;
  return r.data;
}
async function submit(rows,error='') {
  if(!assignment) return false;
  const a=assignment;
  const r=await bridge('/api/submit','POST',{worker_id:workerId,job_id:a.job_id,mpn:a.mpn,rows,error});
  if(r.ok&&r.data?.accepted){assignment=null;rowsSig='';rowsSince=0;lastStatus='';return true;}
  return false;
}

async function tick() {
  if(ticking) return;
  ticking=true;
  try {
    await heartbeat();
    if(!assignment) {
      const c=await claim();
      if(!c?.active){ensureBanner('connected · waiting for RUN','ok');return;}
      if(c.waiting){ensureBanner(c.paused?'paused for security check':'waiting for worker slot',c.paused?'warn':'idle');return;}
      assignment=c; pageStarted=Date.now(); rowsSig=''; rowsSince=0; lastStatus='';
    }
    const expected=assignment.mpn;
    if(key(currentPageMPN())!==key(expected)) {
      ensureBanner('opening '+expected+'…');
      await status('navigating','Opening TrustedParts search');
      location.replace(assignment.url);
      return;
    }
    if(challengeOpen()) {
      ensureBanner('security check — complete it manually','warn');
      await status('verification','Complete TrustedParts security check manually');
      return;
    }
    const rows=extractRows(expected);
    if(rows.length) {
      const sig=JSON.stringify(rows);
      if(sig!==rowsSig){rowsSig=sig;rowsSince=Date.now();ensureBanner(`found ${rows.length} distributor row(s), waiting for REAL-TIME stock…`);return;}
      if(Date.now()-rowsSince>=ROWS_STABLE_MS && Date.now()-pageStarted>=MIN_PAGE_AGE_MS) {
        ensureBanner(`captured ${rows.length} distributor row(s) for ${expected}`,'ok');
        await status('captured',`${rows.length} visible distributor rows`);
        if(await submit(rows)) schedule(20);
        return;
      }
    } else { rowsSig=''; rowsSince=0; }

    if(noResultPage()&&Date.now()-pageStarted>600) {
      ensureBanner('no result: '+expected,'warn');
      await submit([], 'No TrustedParts result found');
      return;
    }
    if(Date.now()-pageStarted>14000) {
      ensureBanner('table timeout: '+expected,'warn');
      await submit([], 'TrustedParts distributor table was not found within 14 seconds');
      return;
    }
    ensureBanner('waiting for distributor table: '+expected);
    await status('waiting_table','Waiting for Distributor / RoHS / Datasheet / Distributor Part # / Pkg (MOQ) / Stock / Pricing');
  } catch(e) {
    ensureBanner('bridge error: '+clean(e?.message||e),'warn');
  } finally { ticking=false; }
}

function schedule(delay=80) {
  if(timer) return;
  timer=setTimeout(()=>{timer=null;tick();},delay);
}
const mo=new MutationObserver(ms=>{
  for(const m of ms){
    const t=m.target?.nodeType===1?m.target:m.target?.parentElement;
    if(t?.closest?.('#__tpbi_v7')) continue;
    schedule(60); break;
  }
});
mo.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
setInterval(()=>schedule(0),1000);
ensureBanner('V7 realtime stock fix loaded','ok');
schedule(0);
