'use strict';
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'bridgeFetch') return;
  const path=String(message.path||'/');
  if(!path.startsWith('/api/')){sendResponse({ok:false,error:'Invalid local API path'});return;}
  (async()=>{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),5000);
    try{
      const init={method:message.method||'GET',cache:'no-store',signal:controller.signal,headers:{'Content-Type':'application/json'}};
      if(message.body!==undefined&&init.method!=='GET')init.body=JSON.stringify(message.body);
      const r=await fetch('http://127.0.0.1:8877'+path,init); let data={};
      try{data=await r.json();}catch(_){ }
      return {ok:r.ok,status:r.status,data};
    }catch(e){return {ok:false,error:String(e&&e.message||e)};}
    finally{clearTimeout(timer);}
  })().then(sendResponse);
  return true;
});
