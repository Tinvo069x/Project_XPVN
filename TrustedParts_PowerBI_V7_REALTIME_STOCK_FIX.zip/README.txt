TrustedParts Power BI V7 - REALTIME STOCK FIX / AUTO BRIDGE

QUICK START
1. Extract the whole ZIP to a normal local folder.
2. Close any old V4/V5 start.bat window if it is still open.
3. Run start.bat.
4. Click CONNECT EDGE.
5. Wait until the dashboard shows at least 1 Edge worker connected.
6. Load the MPN file and click RUN.

NO MANUAL EXTENSION SETUP
- V7 uses a persistent dedicated Edge profile for TrustedParts cookies/session.
- CONNECT EDGE automatically loads the local bridge extension.
- It restarts only this dedicated TrustedParts Edge profile so an old Edge process cannot silently ignore extension launch flags.
- It does not target your normal Edge profile/windows.

AUTO REPAIR
- start.bat checks port 8877 first. If an older TrustedParts V4/V5 server is still listening, it closes that old server before starting V6.
- If Edge opens but worker remains 0/2, click REPAIR EDGE once.

OUTPUT
MPN XP | Distributor | RoHS | Datasheet | Distributor Part # | Pkg (MOQ) | Stock | Pricing

NOTES
- Force live refresh bypasses the local 10-minute cache.
- If TrustedParts itself shows a security check/CAPTCHA, complete it manually in the dedicated Edge window; the queue pauses instead of bypassing it.


V7 Stock fix:
- Waits for TrustedParts REAL-TIME stock refresh to stabilize before capturing.
- Reads explicit status values such as 219,932 In Stock and 380,749 On Order from the Stock cell.
- Uses a new V7 cache so old incorrect V6 stock values are not reused.
