@echo off
setlocal
cd /d "%~dp0"
title Octopart Power BI V10 - Adaptive Edge
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found in PATH.
  pause
  exit /b 1
)
echo Starting Octopart Power BI V10 on http://127.0.0.1:8876
echo Adaptive mode: starts with 1 worker, auto-scales to 2 after clean captures.
echo Cache default: 10 minutes. Use Force live refresh in the UI to bypass cache.
echo Optional: set OCTOPART_MAX_WORKERS=1 to force Safe mode.
python app.py
pause
