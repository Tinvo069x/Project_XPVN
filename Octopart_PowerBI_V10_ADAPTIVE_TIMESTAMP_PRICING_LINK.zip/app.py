from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HTML_NAME = "Octopart_PowerBI_Matcher.html"
HOST = "127.0.0.1"
PORT = 8876
MAX_WORKERS = max(1, min(int(os.environ.get("OCTOPART_MAX_WORKERS", "2")), 2))
WORKER_FRESH_SECONDS = 10
ASSIGNMENT_TIMEOUT = 30
CACHE_TTL_SECONDS = max(0, int(os.environ.get("OCTOPART_CACHE_TTL", "600")))
CACHE_FILE = ROOT / ".octopart_cache.json"


def clean(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ")).strip()


def mpn_key(value):
    return re.sub(r"[^A-Z0-9]", "", clean(value).upper())


def find_edge():
    env = os.environ.get("OCTOPART_EDGE") or os.environ.get("EDGE_PATH")
    candidates = [env] if env else []
    for name in ("msedge", "msedge.exe"):
        p = shutil.which(name)
        if p:
            candidates.append(p)
    if sys.platform.startswith("win"):
        for base in filter(None, [os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"), os.environ.get("LOCALAPPDATA")]):
            candidates.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
    elif sys.platform == "darwin":
        candidates.append("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")
    else:
        for name in ("microsoft-edge", "microsoft-edge-stable"):
            p = shutil.which(name)
            if p:
                candidates.append(p)
    seen = set()
    for p in candidates:
        if not p:
            continue
        p = os.path.abspath(p)
        if p in seen:
            continue
        seen.add(p)
        if os.path.isfile(p):
            return p
    return None


EDGE = find_edge()


def octopart_url(mpn: str, worker_id: str = "") -> str:
    params = [
        ("autosugg_idx", "test"),
        ("currency", "VND"),
        ("specs", "0"),
        ("full_query", mpn + " "),
        ("q", mpn),
        ("nq", mpn),
        ("s", "1"),
        ("inference", "1"),
        ("query_type", "MPN"),
    ]
    if worker_id:
        params.append(("opbi_worker", worker_id))
    return "https://octopart.com/search?" + urllib.parse.urlencode(params)


def worker_home(worker_id: str) -> str:
    return "https://octopart.com/?" + urllib.parse.urlencode({"opbi_worker": worker_id})


def open_edge_workers():
    urls = [worker_home(str(i + 1)) for i in range(MAX_WORKERS)]
    if not EDGE:
        for u in urls:
            webbrowser.open(u)
        return
    profile = ROOT / ".octopart_edge_v10_profile"
    extension = ROOT / "edge_extension"
    profile.mkdir(exist_ok=True)
    args = [
        EDGE,
        f"--user-data-dir={profile}",
        f"--load-extension={extension}",
        "--new-window",
        *urls,
    ]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


class QueueState:
    def __init__(self):
        self.lock = threading.RLock()
        self.job = None
        self.workers = {}
        self.cache = self._load_cache()

    def _load_cache(self):
        try:
            if CACHE_FILE.exists():
                obj = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
                return obj if isinstance(obj, dict) else {}
        except Exception:
            pass
        return {}

    def _save_cache(self):
        try:
            tmp = CACHE_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.cache, ensure_ascii=False), encoding="utf-8")
            tmp.replace(CACHE_FILE)
        except Exception:
            pass

    def _cache_get(self, mpn):
        if CACHE_TTL_SECONDS <= 0:
            return None
        item = self.cache.get(mpn_key(mpn))
        if not isinstance(item, dict):
            return None
        if time.time() - float(item.get("ts", 0)) > CACHE_TTL_SECONDS:
            return None
        rows = item.get("rows")
        required = {"Distributor", "SKU", "Stock", "Min", "Pkg", "Bulk Pricing", "1", "10", "100", "1,000", "10,000"}
        if not isinstance(rows, list) or not rows:
            return None
        # Ignore cache written by older 4-column builds so the new pricing fields are always live/correct.
        if not all(isinstance(r, dict) and required.issubset(r.keys()) for r in rows):
            return None
        return rows

    def _cache_put(self, mpn, rows):
        if not rows:
            return
        self.cache[mpn_key(mpn)] = {"ts": time.time(), "mpn": mpn, "rows": rows}
        self._save_cache()

    def _worker_connected(self, wid, now=None):
        now = now or time.time()
        w = self.workers.get(wid)
        return bool(w and now - w.get("seen", 0) <= WORKER_FRESH_SECONDS)

    def workers_payload(self):
        now = time.time()
        out = []
        for wid, w in sorted(self.workers.items()):
            age = now - w.get("seen", 0)
            out.append({
                "worker_id": wid,
                "connected": age <= WORKER_FRESH_SECONDS,
                "age": round(age, 1),
                "url": w.get("url", ""),
                "title": w.get("title", ""),
            })
        return out

    def heartbeat(self, wid, url="", title=""):
        wid = clean(wid) or "1"
        with self.lock:
            self.workers[wid] = {"seen": time.time(), "url": clean(url), "title": clean(title)}
            return self.job_payload()

    def start_job(self, mpns, force_refresh=False):
        with self.lock:
            if self.job and self.job.get("active"):
                raise RuntimeError("Another Octopart job is already running")
            jid = uuid.uuid4().hex
            results = {}
            cached = 0
            if not force_refresh:
                for i, mpn in enumerate(mpns):
                    rows = self._cache_get(mpn)
                    if rows:
                        results[i] = {"inputMPN": mpn, "rows": rows, "cached": True}
                        cached += 1
            self.job = {
                "id": jid,
                "mpns": list(mpns),
                "active": len(results) < len(mpns),
                "cancelled": False,
                "started": time.time(),
                "updated": time.time(),
                "results": results,
                "assignments": {},
                "status": {},
                "concurrency": 1,
                "success_streak": 0,
                "challenge_until": 0.0,
                "cached": cached,
            }
            return jid

    def _reap_stale_assignments(self):
        if not self.job or not self.job.get("active"):
            return
        now = time.time()
        stale = []
        for wid, a in self.job["assignments"].items():
            if now - a.get("claimed", now) > ASSIGNMENT_TIMEOUT and not self._worker_connected(wid, now):
                stale.append(wid)
        for wid in stale:
            self.job["assignments"].pop(wid, None)
            self.job["status"].pop(wid, None)

    def _challenge_active(self):
        j = self.job
        if not j:
            return False
        now = time.time()
        any_verification = any(s.get("status") == "verification" for s in j.get("status", {}).values())
        return any_verification or now < float(j.get("challenge_until", 0))

    def claim(self, wid):
        wid = clean(wid) or "1"
        with self.lock:
            j = self.job
            if not j or not j.get("active"):
                return {"active": False}
            self._reap_stale_assignments()
            if wid in j["assignments"]:
                idx = j["assignments"][wid]["idx"]
                if idx not in j["results"]:
                    return self._assignment_payload(j, wid, idx, j["mpns"][idx])
                j["assignments"].pop(wid, None)

            # Security challenge: do not keep opening more Octopart pages.
            if self._challenge_active():
                return {"active": True, "waiting": True, "paused": True, "reason": "security_check", "job_id": j["id"]}

            active_assignments = sum(1 for a in j["assignments"].values() if a["idx"] not in j["results"])
            if active_assignments >= int(j.get("concurrency", 1)):
                return {"active": True, "waiting": True, "job_id": j["id"]}

            assigned_idxs = {a["idx"] for a in j["assignments"].values()}
            next_idx = next((i for i in range(len(j["mpns"])) if i not in j["results"] and i not in assigned_idxs), None)
            if next_idx is None:
                if len(j["results"]) >= len(j["mpns"]):
                    j["active"] = False
                    return {"active": False, "complete": True}
                return {"active": True, "waiting": True, "job_id": j["id"]}

            j["assignments"][wid] = {"idx": next_idx, "claimed": time.time()}
            return self._assignment_payload(j, wid, next_idx, j["mpns"][next_idx])

    def _assignment_payload(self, j, wid, idx, mpn):
        return {
            "active": True,
            "waiting": False,
            "job_id": j["id"],
            "worker_id": wid,
            "index": idx,
            "total": len(j["mpns"]),
            "mpn": mpn,
            "url": octopart_url(mpn, wid),
        }

    def set_status(self, wid, job_id, mpn, status, detail=""):
        wid = clean(wid) or "1"
        with self.lock:
            j = self.job
            if not j or j["id"] != job_id:
                return False
            a = j["assignments"].get(wid)
            if not a:
                return False
            expected = j["mpns"][a["idx"]]
            if mpn_key(expected) != mpn_key(mpn):
                return False
            st = clean(status)[:80]
            j["status"][wid] = {"status": st, "detail": clean(detail)[:240], "updated": time.time()}
            if st == "verification":
                j["concurrency"] = 1
                j["success_streak"] = 0
                j["challenge_until"] = time.time() + 20
            elif st in {"waiting_table", "captured", "navigating"}:
                # Once the challenged tab progresses again, don't artificially hold the queue.
                if not any(x.get("status") == "verification" for k, x in j["status"].items() if k != wid):
                    j["challenge_until"] = min(float(j.get("challenge_until", 0)), time.time() + 1)
            j["updated"] = time.time()
            return True

    def submit(self, wid, job_id, mpn, rows, error=""):
        wid = clean(wid) or "1"
        with self.lock:
            j = self.job
            if not j or j["id"] != job_id:
                return {"accepted": False, "reason": "job_not_active"}
            a = j["assignments"].get(wid)
            if not a:
                return {"accepted": False, "reason": "no_assignment"}
            idx = a["idx"]
            expected = j["mpns"][idx]
            if mpn_key(expected) != mpn_key(mpn):
                return {"accepted": False, "reason": "mpn_mismatch", "expected": expected}

            normalized = []
            if isinstance(rows, list):
                seen = set()
                for raw in rows:
                    if not isinstance(raw, dict):
                        continue
                    dist = clean(raw.get("Distributor"))
                    sku = clean(raw.get("SKU"))
                    stock = raw.get("Stock", "")
                    if isinstance(stock, str):
                        s = clean(stock)
                        compact = s.replace(",", "").replace(" ", "")
                        stock = int(compact) if compact.isdigit() else s
                    if not sku or stock == "":
                        continue
                    extra = {
                        "Min": clean(raw.get("Min")),
                        "Pkg": clean(raw.get("Pkg")),
                        "Bulk Pricing": clean(raw.get("Bulk Pricing")),
                        "1": clean(raw.get("1")),
                        "10": clean(raw.get("10")),
                        "100": clean(raw.get("100")),
                        "1,000": clean(raw.get("1,000")),
                        "10,000": clean(raw.get("10,000")),
                    }
                    sig = (dist.casefold(), sku.casefold(), str(stock), *(extra[k].casefold() for k in ("Min","Pkg","Bulk Pricing","1","10","100","1,000","10,000")))
                    if sig in seen:
                        continue
                    seen.add(sig)
                    normalized.append({"MPN_XP": expected, "Distributor": dist, "SKU": sku, "Stock": stock, **extra})

            err = clean(error)
            j["results"][idx] = {"inputMPN": expected, "rows": normalized, **({"error": err} if err else {})}
            j["assignments"].pop(wid, None)
            j["status"].pop(wid, None)
            j["updated"] = time.time()

            if normalized and not err:
                self._cache_put(expected, normalized)
                j["success_streak"] = int(j.get("success_streak", 0)) + 1
                # Start conservatively. After 3 clean pages, enable the second worker.
                if MAX_WORKERS >= 2 and j["success_streak"] >= 3 and not self._challenge_active():
                    j["concurrency"] = 2
            else:
                j["success_streak"] = 0

            if len(j["results"]) >= len(j["mpns"]):
                j["active"] = False
            return {"accepted": True, "complete": not j["active"], "completed": len(j["results"]), "total": len(j["mpns"]), "concurrency": j["concurrency"]}

    def cancel(self):
        with self.lock:
            if not self.job or not self.job.get("active"):
                return False
            self.job["active"] = False
            self.job["cancelled"] = True
            self.job["updated"] = time.time()
            return True

    def job_payload(self):
        with self.lock:
            now = time.time()
            workers = self.workers_payload() if self.workers else []
            j = self.job
            if not j:
                return {"active": False, "workers": workers}
            status = []
            for wid, a in sorted(j["assignments"].items()):
                idx = a["idx"]
                st = j["status"].get(wid, {})
                status.append({
                    "worker_id": wid,
                    "mpn": j["mpns"][idx],
                    "status": st.get("status", "assigned"),
                    "detail": st.get("detail", ""),
                })
            return {
                "active": bool(j.get("active")),
                "cancelled": bool(j.get("cancelled")),
                "job_id": j["id"],
                "completed": len(j["results"]),
                "total": len(j["mpns"]),
                "elapsed": round(now - j["started"], 1),
                "assignments": status,
                "workers": workers,
                "concurrency": int(j.get("concurrency", 1)),
                "cached": int(j.get("cached", 0)),
                "security_pause": self._challenge_active(),
            }

    def results_payload(self):
        with self.lock:
            j = self.job
            if not j:
                return {"results": []}
            out = []
            for idx, mpn in enumerate(j["mpns"]):
                if idx in j["results"]:
                    out.append(j["results"][idx])
                else:
                    err = "Cancelled" if j.get("cancelled") else "No result returned"
                    out.append({"inputMPN": mpn, "rows": [], "error": err})
            return {"results": out, "active": bool(j.get("active")), "completed": len(j["results"]), "total": len(j["mpns"])}


STATE = QueueState()


class Handler(BaseHTTPRequestHandler):
    server_version = "OctopartPowerBI/10.0-AdaptiveEdge"

    def log_message(self, fmt, *args):
        msg = fmt % args
        if any(x in msg for x in ("GET /api/health ", "GET /api/job ")):
            return
        print("[%s] %s" % (self.log_date_time_string(), msg))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def send_json(self, data, status=200):
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > 5_000_000:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(length) or b"{}")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/health":
            workers = STATE.workers_payload()
            connected = sum(1 for w in workers if w["connected"])
            self.send_json({
                "app": "octopart-stock",
                "version": "10.0-adaptive-edge",
                "port": PORT,
                "browser": bool(EDGE),
                "browser_name": "Microsoft Edge",
                "source": "octopart.com/search",
                "worker_target": MAX_WORKERS,
                "worker_connected": connected,
                "workers": workers,
            })
            return
        if path == "/api/job":
            self.send_json(STATE.job_payload())
            return
        if path == "/api/results":
            self.send_json(STATE.results_payload())
            return
        if path in ("/", "/index.html", f"/{HTML_NAME}"):
            file = ROOT / HTML_NAME
            if not file.exists():
                self.send_error(404, f"{HTML_NAME} not found")
                return
            raw = file.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)
            return
        self.send_error(404)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        try:
            payload = self.read_json()
            if path == "/api/open-edge":
                open_edge_workers()
                self.send_json({"ok": True, "workers": MAX_WORKERS})
                return
            if path == "/api/worker/heartbeat":
                state = STATE.heartbeat(payload.get("worker_id"), payload.get("url"), payload.get("title"))
                self.send_json({"ok": True, "job": state})
                return
            if path == "/api/claim":
                STATE.heartbeat(payload.get("worker_id"), payload.get("url"), payload.get("title"))
                self.send_json(STATE.claim(payload.get("worker_id")))
                return
            if path == "/api/status":
                ok = STATE.set_status(payload.get("worker_id"), clean(payload.get("job_id")), clean(payload.get("mpn")), clean(payload.get("status")), clean(payload.get("detail")))
                self.send_json({"ok": ok})
                return
            if path == "/api/submit":
                result = STATE.submit(payload.get("worker_id"), clean(payload.get("job_id")), clean(payload.get("mpn")), payload.get("rows") or [], clean(payload.get("error")))
                self.send_json(result, 200 if result.get("accepted") else 409)
                return
            if path == "/api/start":
                mpns = payload.get("mpns") or []
                if not isinstance(mpns, list) or not mpns:
                    raise ValueError("mpns must be a non-empty array")
                cleaned, seen = [], set()
                for value in mpns:
                    m = clean(value)
                    k = mpn_key(m)
                    if m and k and k not in seen:
                        seen.add(k); cleaned.append(m)
                if not cleaned:
                    raise ValueError("No valid MPN values")
                if len(cleaned) > 5000:
                    raise ValueError("Maximum 5,000 MPN per run")
                connected = sum(1 for w in STATE.workers_payload() if w["connected"])
                if connected < 1:
                    raise RuntimeError("No Edge worker is connected. Click CONNECT EDGE first.")
                jid = STATE.start_job(cleaned, bool(payload.get("fresh")))
                jp = STATE.job_payload()
                self.send_json({"ok": True, "job_id": jid, "total": len(cleaned), "workers_connected": connected, "cached": jp.get("cached", 0), "concurrency": jp.get("concurrency", 1)})
                return
            if path == "/api/cancel":
                self.send_json({"ok": STATE.cancel()})
                return
            self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc)}, 400)


def main():
    if not (ROOT / HTML_NAME).exists():
        print(f"Missing {HTML_NAME} in {ROOT}")
        raise SystemExit(1)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}/"
    print("==============================================================")
    print(" Octopart Power BI V10 - ADAPTIVE EDGE")
    print("==============================================================")
    print(f"Local UI : {url}")
    print(f"Workers  : up to {MAX_WORKERS} Edge tabs; starts with 1 and auto-scales to 2")
    print("Source   : octopart.com/search -> visible Price & Availability")
    print("Output   : MPN_XP | Distributor | SKU | Stock | Min | Pkg | Bulk Pricing | 1 | 10 | 100 | 1,000 | 10,000")
    print("Security : verification pauses new assignments; complete it manually.")
    print(f"Cache    : {CACHE_TTL_SECONDS}s local cache; Force Live Refresh bypasses it")
    print("==============================================================")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
