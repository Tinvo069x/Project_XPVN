'use strict';

const clean = v => String(v == null ? '' : v).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
const norm = v => clean(v).toLowerCase().replace(/[^a-z0-9]/g, '');
const key = v => clean(v).toUpperCase().replace(/[^A-Z0-9]/g, '');

function bridge(path, method = 'GET', body = undefined) {
  return new Promise(resolve => chrome.runtime.sendMessage({type:'bridgeFetch', path, method, body}, r => {
    if (chrome.runtime.lastError) return resolve({ok:false, error:chrome.runtime.lastError.message});
    resolve(r || {ok:false, error:'No bridge response'});
  }));
}

function visible(el) {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  if (r.width <= 0 || r.height <= 0) return false;
  const s = getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
}

function bodyText() { return clean(document.body?.innerText || ''); }
function challengeOpen() {
  const t = bodyText().toLowerCase();
  return ['one more step','please complete the security check','press again','press & hold','verify you are human','captcha','checking your browser','security verification','access denied','unusual traffic','please try again'].some(x => t.includes(x));
}
function noResultPage() {
  const t = bodyText().toLowerCase();
  return /results\s*:\s*0\b/.test(t) || t.includes('no results') || t.includes('0 results');
}
function resultsCount() {
  const m = bodyText().match(/Results\s*:\s*(\d+)/i);
  return m ? Number(m[1]) : null;
}
function currentPageMPN() {
  try {
    const u = new URL(location.href);
    return clean(u.searchParams.get('q') || u.searchParams.get('nq') || u.searchParams.get('full_query') || '').replace(/\s+$/,'');
  } catch (_) { return ''; }
}
function getWorkerId() {
  try {
    const u = new URL(location.href);
    const q = clean(u.searchParams.get('opbi_worker'));
    if (q) { sessionStorage.setItem('opbi_worker', q); return q; }
  } catch (_) {}
  let w = clean(sessionStorage.getItem('opbi_worker'));
  if (!w) { w = String(Math.floor(Math.random()*900000)+100000); sessionStorage.setItem('opbi_worker', w); }
  return w;
}

const workerId = getWorkerId();
let assignment = null;
let lastHeartbeat = 0;
let ticking = false;
let timer = null;
let rowsSig = '';
let rowsSince = 0;
let pageStarted = Date.now();
let lastStatus = '';

function ensureBanner(text, mode='idle') {
  let el = document.getElementById('__opbi_v10');
  if (!el) {
    el = document.createElement('div');
    el.id = '__opbi_v10';
    Object.assign(el.style, {
      position:'fixed', right:'14px', bottom:'14px', zIndex:'2147483647',
      fontFamily:'Segoe UI,Arial,sans-serif', fontSize:'12px', padding:'8px 10px',
      borderRadius:'7px', boxShadow:'0 2px 10px rgba(0,0,0,.18)', maxWidth:'430px'
    });
    document.documentElement.appendChild(el);
  }
  const p = mode === 'ok' ? ['#ecfdf3','#067647','#abefc6'] : mode === 'warn' ? ['#fffaeb','#7a2e0e','#fedf89'] : ['#eff8ff','#175cd3','#b2ddff'];
  el.style.background=p[0]; el.style.color=p[1]; el.style.border='1px solid '+p[2];
  el.textContent=`Octopart Power BI W${workerId}: ${text}`;
}

async function heartbeat() {
  const now = Date.now();
  if (now - lastHeartbeat < 5000) return;
  lastHeartbeat = now;
  await bridge('/api/worker/heartbeat','POST',{worker_id:workerId,url:location.href,title:document.title});
}
async function status(st, detail='') {
  if (!assignment) return;
  const sig = st+'|'+detail;
  if (sig === lastStatus) return;
  lastStatus = sig;
  await bridge('/api/status','POST',{worker_id:workerId,job_id:assignment.job_id,mpn:assignment.mpn,status:st,detail});
}

function textCandidates(root,label) {
  const wanted = norm(label);
  return [...root.querySelectorAll('th,td,div,span,p')].filter(el => visible(el) && norm(el.innerText || el.textContent) === wanted);
}
function headerSet(root) {
  return textCandidates(root,'Distributor').length && textCandidates(root,'SKU').length && textCandidates(root,'Stock').length;
}

function exactMPNElements(expected) {
  const k = key(expected);
  return [...document.querySelectorAll('a,h1,h2,h3,span,div')].filter(el => {
    if (!visible(el)) return false;
    const t = clean(el.innerText || el.textContent);
    return t && key(t) === k;
  });
}

function findOfferRoot(expected) {
  const cands = [];
  for (const el of exactMPNElements(expected)) {
    let p = el;
    for (let depth=0; depth<12 && p; depth++, p=p.parentElement) {
      if (!visible(p)) continue;
      if (headerSet(p)) {
        const r = p.getBoundingClientRect();
        const area = Math.max(1, r.width*r.height);
        cands.push({p,area,depth});
        break;
      }
    }
  }
  if (cands.length) {
    cands.sort((a,b)=>a.area-b.area || a.depth-b.depth);
    return cands[0].p;
  }
  // Safe fallback only when Octopart reports exactly one result.
  if (resultsCount() === 1) {
    const roots=[...document.querySelectorAll('main,section,article,div')].filter(x=>visible(x)&&headerSet(x));
    if (roots.length) {
      roots.sort((a,b)=>{
        const ra=a.getBoundingClientRect(), rb=b.getBoundingClientRect();
        return ra.width*ra.height-rb.width*rb.height;
      });
      return roots[0];
    }
  }
  return null;
}

function numericText(t) {
  t = clean(t);
  return /^\d{1,3}(?:,\d{3})+$/.test(t) || /^\d+$/.test(t);
}
function firstAnchor(cell, rejectNumeric=false) {
  if (!cell) return '';
  for (const a of cell.querySelectorAll('a')) {
    if (!visible(a)) continue;
    const t=clean(a.innerText||a.textContent);
    if (!t) continue;
    if (rejectNumeric && numericText(t)) continue;
    return t;
  }
  return clean(cell.innerText||cell.textContent);
}
function directCells(row) {
  return [...row.children].filter(el=>{
    const t=String(el.tagName||'').toLowerCase(), r=String(el.getAttribute?.('role')||'').toLowerCase();
    return t==='td'||t==='th'||r==='cell'||r==='gridcell'||r==='columnheader';
  });
}

function cellText(cell) {
  if (!cell) return '';
  return clean(cell.innerText || cell.textContent || '');
}

const OFFER_FIELDS=['Distributor','SKU','Stock','Min','Pkg','Bulk Pricing','1','10','100','1,000','10,000'];
const OPTIONAL_HEADERS=['Min','Pkg','Bulk Pricing','1','10','100','1,000','10,000'];

function extractStructured(root) {
  if (!root) return [];
  const containers=[...root.querySelectorAll('table,[role="table"],[role="grid"]')];
  if(root.matches?.('table,[role="table"],[role="grid"]')) containers.unshift(root);
  for(const c of containers) {
    if(!visible(c)) continue;
    const rows=String(c.tagName||'').toLowerCase()==='table'?[...c.querySelectorAll('tr')]:[...c.querySelectorAll('[role="row"]')];
    let hi=-1, indexes=null;
    for(let i=0;i<rows.length;i++) {
      const cells=directCells(rows[i]), names=cells.map(x=>norm(x.innerText||x.textContent));
      const idx={};
      for(const label of OFFER_FIELDS) idx[label]=names.indexOf(norm(label));
      if(idx.Distributor>=0&&idx.SKU>=0&&idx.Stock>=0){hi=i;indexes=idx;break;}
    }
    if(hi<0||!indexes) continue;
    const out=[];
    for(let i=hi+1;i<rows.length;i++) {
      const row=rows[i]; if(!visible(row)) continue;
      const cells=directCells(row); if(cells.length<=Math.max(indexes.Distributor,indexes.SKU,indexes.Stock)) continue;
      const dist=clean(firstAnchor(cells[indexes.Distributor],true));
      const sku=clean(firstAnchor(cells[indexes.SKU],true));
      let stock='';
      for(const a of cells[indexes.Stock].querySelectorAll('a')) {
        const t=clean(a.innerText||a.textContent);
        if(visible(a)&&numericText(t)){stock=t;break;}
      }
      if(!stock) {
        const m=cellText(cells[indexes.Stock]).match(/\d{1,3}(?:,\d{3})+|\d+/);
        stock=m?m[0]:'';
      }
      if(!sku||!stock) continue;
      const rec={Distributor:dist,SKU:sku,Stock:stock};
      for(const label of OPTIONAL_HEADERS) {
        const ix=indexes[label];
        rec[label]=(ix>=0&&ix<cells.length)?cellText(cells[ix]):'';
      }
      out.push(rec);
    }
    if(out.length) return out;
  }
  return [];
}

function extractGeometry(root) {
  if (!root) return [];
  const ds=textCandidates(root,'Distributor'), ss=textCandidates(root,'SKU'), ts=textCandidates(root,'Stock');
  if(!ds.length||!ss.length||!ts.length) return [];
  let best=null;
  for(const d of ds) for(const s of ss) for(const t of ts) {
    const rd=d.getBoundingClientRect(), rs=s.getBoundingClientRect(), rt=t.getBoundingClientRect();
    const yd=(rd.top+rd.bottom)/2, ys=(rs.top+rs.bottom)/2, yt=(rt.top+rt.bottom)/2;
    if(Math.max(yd,ys,yt)-Math.min(yd,ys,yt)>30) continue;
    const xd=(rd.left+rd.right)/2, xs=(rs.left+rs.right)/2, xt=(rt.left+rt.right)/2;
    if(!(xd<xs&&xs<xt)) continue;
    const score=xt-xd;
    if(!best||score>best.score) best={d,s,t,rd,rs,rt,xd,xs,xt,score,bottom:Math.max(rd.bottom,rs.bottom,rt.bottom)};
  }
  if(!best) return [];

  const headerY=((best.rd.top+best.rd.bottom)+(best.rs.top+best.rs.bottom)+(best.rt.top+best.rt.bottom))/6;
  const headers=[
    {name:'Distributor',x:best.xd,el:best.d},
    {name:'SKU',x:best.xs,el:best.s},
    {name:'Stock',x:best.xt,el:best.t}
  ];
  let minX=best.xt+4;
  for(const label of OPTIONAL_HEADERS) {
    const cands=textCandidates(root,label).map(el=>{
      const r=el.getBoundingClientRect();
      return {el,r,x:(r.left+r.right)/2,y:(r.top+r.bottom)/2};
    }).filter(x=>Math.abs(x.y-headerY)<30&&x.x>minX);
    if(!cands.length) continue;
    cands.sort((a,b)=>a.x-b.x);
    const pick=cands[0]; headers.push({name:label,x:pick.x,el:pick.el}); minX=pick.x+3;
  }
  headers.sort((a,b)=>a.x-b.x);
  const indexByName=Object.fromEntries(headers.map((h,i)=>[h.name,i]));
  const bounds=headers.map((h,i)=>({
    name:h.name,
    x:h.x,
    left:i===0?Math.max(root.getBoundingClientRect().left,h.x-(headers[i+1].x-h.x)/2):(headers[i-1].x+h.x)/2,
    right:i===headers.length-1?root.getBoundingClientRect().right:(h.x+headers[i+1].x)/2
  }));
  const boundOf=name=>bounds[indexByName[name]]||null;
  const distB=boundOf('Distributor'), skuB=boundOf('SKU'), stockB=boundOf('Stock');
  if(!distB||!skuB||!stockB) return [];

  let bottom=root.getBoundingClientRect().bottom;
  for(const el of root.querySelectorAll('a,button,div,span')) {
    if(!visible(el)) continue;
    const t=clean(el.innerText||el.textContent);
    if(!/^(show all|see all)$/i.test(t)) continue;
    const r=el.getBoundingClientRect();
    if(r.top>best.bottom&&r.top<bottom) bottom=r.top+2;
  }

  const anchors=[...root.querySelectorAll('a')].filter(a=>{
    if(!visible(a)) return false;
    const r=a.getBoundingClientRect(), cy=(r.top+r.bottom)/2, cx=(r.left+r.right)/2;
    return cy>best.bottom+3&&cy<bottom&&cx>=distB.left&&cx<=stockB.right;
  });
  const groups=[];
  for(const a of anchors) {
    const r=a.getBoundingClientRect(), cy=(r.top+r.bottom)/2;
    let g=groups.find(x=>Math.abs(x.y-cy)<=9);
    if(!g){g={y:cy,items:[]};groups.push(g);}
    g.items.push({text:clean(a.innerText||a.textContent),cx:(r.left+r.right)/2});
  }
  groups.sort((a,b)=>a.y-b.y);

  function textAtRow(bound,y) {
    if(!bound) return '';
    const center=(bound.left+bound.right)/2, width=Math.max(1,bound.right-bound.left);
    const selectors='a,td,th,span,div,[role="cell"],[role="gridcell"]';
    const cands=[];
    for(const el of root.querySelectorAll(selectors)) {
      if(!visible(el)) continue;
      const txt=clean(el.innerText||el.textContent); if(!txt) continue;
      const r=el.getBoundingClientRect(), cy=(r.top+r.bottom)/2, cx=(r.left+r.right)/2;
      if(cy<=best.bottom+2||cy>=bottom||Math.abs(cy-y)>13) continue;
      if(cx<bound.left||cx>bound.right) continue;
      if(r.width>width*1.75) continue;
      const area=Math.max(1,r.width*r.height);
      const tag=String(el.tagName||'').toLowerCase();
      const role=String(el.getAttribute?.('role')||'').toLowerCase();
      const typePenalty=(tag==='a'||tag==='td'||role==='cell'||role==='gridcell')?0:5000;
      const score=Math.abs(cy-y)*1000+Math.abs(cx-center)*5+area/50+typePenalty;
      cands.push({txt,score});
    }
    cands.sort((a,b)=>a.score-b.score);
    return cands.length?cands[0].txt:'';
  }

  const out=[];
  for(const g of groups) {
    const dist=g.items.find(x=>x.cx>=distB.left&&x.cx<distB.right&&x.text&&!numericText(x.text));
    const sku=g.items.find(x=>x.cx>=skuB.left&&x.cx<skuB.right&&x.text&&!numericText(x.text));
    const stockCandidates=g.items.filter(x=>x.cx>=stockB.left&&x.cx<=stockB.right&&numericText(x.text));
    stockCandidates.sort((a,b)=>Math.abs(a.cx-best.xt)-Math.abs(b.cx-best.xt));
    const stk=stockCandidates[0];
    if(!sku||!stk) continue;
    const rec={Distributor:dist?dist.text:'',SKU:sku.text,Stock:stk.text};
    for(const label of OPTIONAL_HEADERS) rec[label]=textAtRow(boundOf(label),g.y);
    out.push(rec);
  }
  return out;
}

function dedupeRows(rows) {
  const out=[], seen=new Set();
  for(const r of rows) {
    const rec={};
    for(const f of OFFER_FIELDS) rec[f]=clean(r?.[f]);
    if(!rec.SKU || !numericText(rec.Stock)) continue;
    if(['distributor','sku','stock','min','pkg'].includes(norm(rec.SKU))) continue;
    const sig=OFFER_FIELDS.map(f=>rec[f].toLowerCase()).join('|');
    if(seen.has(sig)) continue;
    seen.add(sig); out.push(rec);
  }
  return out;
}

function extractRows(expected) {
  const root=findOfferRoot(expected);
  if(!root) return [];
  // Structured DOM is safer; geometry is only a fallback for Octopart's div/grid layout.
  let rows=extractStructured(root);
  if(!rows.length) rows=extractGeometry(root);
  return dedupeRows(rows);
}

async function claim() {
  const r=await bridge('/api/claim','POST',{worker_id:workerId,url:location.href,title:document.title});
  if(!r.ok||!r.data) return null;
  return r.data;
}
async function submit(rows,error='') {
  if(!assignment) return false;
  const a=assignment;
  const r=await bridge('/api/submit','POST',{worker_id:workerId,job_id:a.job_id,mpn:a.mpn,rows,error});
  if(r.ok&&r.data?.accepted){assignment=null;rowsSig='';rowsSince=0;lastStatus='';return true;}
  return false;
}

async function tick() {
  if(ticking) return;
  ticking=true;
  try {
    await heartbeat();
    if(!assignment) {
      const c=await claim();
      if(!c?.active){ensureBanner('connected · waiting for RUN','ok');return;}
      if(c.waiting){ensureBanner(c.paused?'paused for security check':'waiting for worker slot',c.paused?'warn':'idle');return;}
      assignment=c; pageStarted=Date.now(); rowsSig=''; rowsSince=0; lastStatus='';
    }
    const expected=assignment.mpn;
    if(key(currentPageMPN())!==key(expected)) {
      ensureBanner('opening '+expected+'…');
      await status('navigating','Opening Octopart search');
      location.replace(assignment.url);
      return;
    }
    if(challengeOpen()) {
      ensureBanner('security check — complete it manually','warn');
      await status('verification','Complete Octopart security check manually');
      return;
    }
    const rows=extractRows(expected);
    if(rows.length) {
      const sig=JSON.stringify(rows);
      if(sig!==rowsSig){rowsSig=sig;rowsSince=Date.now();ensureBanner(`found ${rows.length} row(s), validating…`);return;}
      if(Date.now()-rowsSince>=180) {
        ensureBanner(`captured ${rows.length} row(s) for ${expected}`,'ok');
        await status('captured',`${rows.length} visible rows`);
        if(await submit(rows)) schedule(20);
        return;
      }
    } else { rowsSig=''; rowsSince=0; }

    if(noResultPage()&&Date.now()-pageStarted>350) {
      ensureBanner('no result: '+expected,'warn');
      await submit([], 'No Octopart result found');
      return;
    }
    if(Date.now()-pageStarted>9000) {
      ensureBanner('table timeout: '+expected,'warn');
      await submit([], 'Price & Availability rows not found within 9 seconds');
      return;
    }
    ensureBanner('waiting for Price & Availability: '+expected);
    await status('waiting_table','Waiting for exact product card and visible Distributor / SKU / Stock rows');
  } catch(e) {
    ensureBanner('bridge error: '+clean(e?.message||e),'warn');
  } finally { ticking=false; }
}

function schedule(delay=80) {
  if(timer) return;
  timer=setTimeout(()=>{timer=null;tick();},delay);
}
const mo=new MutationObserver(ms=>{
  for(const m of ms){
    const t=m.target?.nodeType===1?m.target:m.target?.parentElement;
    if(t?.closest?.('#__opbi_v10')) continue;
    schedule(60); break;
  }
});
mo.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
setInterval(()=>schedule(0),1000);
ensureBanner('adaptive bridge loaded','ok');
schedule(0);
