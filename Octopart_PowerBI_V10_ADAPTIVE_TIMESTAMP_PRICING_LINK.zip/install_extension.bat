@echo off
setlocal
cd /d "%~dp0"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" (
  echo Microsoft Edge not found.
  pause
  exit /b 1
)
start "" "%EDGE%" edge://extensions/
echo.
echo If auto-load does not work:
echo 1. Turn on Developer mode.
echo 2. Click Load unpacked.
echo 3. Select: %~dp0edge_extension
echo.
pause
