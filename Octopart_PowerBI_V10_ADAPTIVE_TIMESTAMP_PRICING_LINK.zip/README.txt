Octopart Power BI V10 - ADAPTIVE EDGE
=====================================

Output
- MPN_XP | Distributor | SKU | Stock | Min | Pkg | Bulk Pricing | 1 | 10 | 100 | 1,000 | 10,000
- Source: visible Octopart Price & Availability rows only.
- Does NOT click Show All.

What V10 changes
1. Starts with ONE Edge worker for stability and accuracy.
2. After 3 clean captures, automatically enables the second worker.
3. If Octopart shows a security check, new assignments pause instead of opening more pages.
4. Exact-MPN product-card lock is stricter. If the exact card cannot be identified, it will not read an unrelated table.
5. Structured table/grid parsing is used first; screen geometry is only a fallback.
6. Successful results are cached locally for 10 minutes, so repeated MPNs return immediately.
7. Check "Force live refresh" in the UI when you need fresh stock and want to bypass cache.
8. Lower background polling reduces CPU/network noise.

Recommended usage
1. Close old V8/V9 dedicated Octopart Edge windows.
2. Run start.bat.
3. Click CONNECT EDGE if no worker is connected.
4. Upload your MPN file.
5. For a normal run, leave Force live refresh UNCHECKED.
6. For live stock validation, check Force live refresh.
7. Click RUN & Export XLSX.
8. If Octopart asks for a security check, complete it manually. V10 will pause new work and resume afterward.

If results still look wrong
- Test one known MPN first (for example RC0805FR-07178RL).
- Turn on Force live refresh.
- Compare only the visible Distributor / SKU / Stock rows above Show All.
- Do not run old V8/V9 Edge profile windows at the same time.

Speed / stability
- Default maximum workers: 2, but V10 starts at 1 and scales automatically.
- Force Safe mode: set OCTOPART_MAX_WORKERS=1 before running app.py.
- Cache TTL: OCTOPART_CACHE_TTL in seconds (default 600).

Important
Browser scraping is still limited by Octopart page-load time and security challenges.
For hundreds or thousands of MPNs, the official Nexar GraphQL API is the proper high-throughput path.

V10 pricing-link upgrade:
- Output columns: MPN_XP | Distributor | SKU | Stock | Min | Pkg | Bulk Pricing | 1 | 10 | 100 | 1,000 | 10,000
- MPN_XP is clickable in the preview and Excel; it opens the exact Octopart search URL for that MPN.
- Excel download name remains Octopart_Power BI_yyyymmdd_hhmm.xlsx.
- Adaptive workers, Edge bridge, cache, Force live refresh, security pause, and visible-row logic are unchanged.
